Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
folder = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = folder

' Uruchamia client.py bez widocznego okna CMD.
' Kolejno probuje: py -3w, pythonw, a na koncu python ukryty przez cmd.
shell.Run "cmd /c py -3w client.py || pythonw client.py || python client.py", 0, False
