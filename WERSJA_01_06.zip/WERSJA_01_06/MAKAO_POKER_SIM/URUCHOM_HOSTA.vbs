Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
folder = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = folder

' Uruchamia host_gui.py bez widocznego okna CMD.
' Kolejno probuje: py -3w, pythonw, a na koncu python ukryty przez cmd.
shell.Run "cmd /c py -3w host_gui.py || pythonw host_gui.py || python host_gui.py", 0, False
